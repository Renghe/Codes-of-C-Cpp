
#include<iostream>
using namespace std;
int main(){
	int i,j,n,k;
	cout<<"enter no. of rows";
	cin>>n;
	for(i=1;i<=n;i++){
	    cout<<"\n";
	    for(j=1;j<=i;j++)
	        cout<<j;
	    for(k=2*(n-i);k>0;k--)
	        cout<<" ";
	    for(j=i;j>=1;j--)
	        cout<<j;
	}
	 
}