#include <stdio.h>
int main ()
{ float a,b,c,d,e,p,t;
  printf ("\n Enter the marks of English , Mar , Hin , Sci , Maths");
  scanf ("%f%f%f%f%f",&a,&b,&c,&d,&e);
   t=a+b+c+d+e;
   printf("\n Total Marks:%.2f",t);
   p=(t/500)*100;
   printf("\n Percentage is:%.2f",p);
   if(a>40 && b>40 && c>40 && d>40 && e>40)
    {printf("\n Student is passed in the all subkects");}
    else{printf("\n Student is Failed in any one subject or more");}
   if (p >= 70 )
   {printf ("\n First Class Distinction");}
   else if (p >= 60 && p < 70)
   {printf ("\n First Class");}
   else if (p >= 50 && p< 60)
   {printf ("\n Second Class");}
   else if (p >= 40 && p < 50)
   {printf ("\n Passed");}
   else
   { printf ("\n Failed(ATKT)");}
}



