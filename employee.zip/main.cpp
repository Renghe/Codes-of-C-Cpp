#include<stdio.h>
#include<srting.h>

struct Employee add();
void disp(struct Employee);


struct Employee{
    int id;
    char name[50];
    float salary;
    };
int main(){
    struct Employee e;
    x=add();
    disp(x);
}

struct Employee add(){
    struct Employee f;
    printf("\n\t ID:");
    scanf("%d",&f.id);
    
    printf("\n\t Name: ");
    scanf("%s",f.name);
    
    printf("\n\t salary:");
    scanf("%f",&f.salary);
    return f;
    
}

void disp(struct Employee g){
    printf("\n\n Details;")
}