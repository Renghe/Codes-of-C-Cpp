#include<stdio.h>

int main()
    {
        int a,b,c;
        printf("\nenter 3 number:");
        scanf("%d%d%d",&a,&b,&c);
        printf("You have entered %d,%d,%d.",a,b,c);
        int sum=a+b+c;
        printf("\nSum=%d",sum);
        float avg=sum/3.0;
        printf("\nAvg=%.2f",avg);
        if(a>b && a>c)
            {
                printf("\nFrom your entered value %d is max",a);
            }
            else if(b>a && b>c)
                {
                    printf("\nFrom your entered value %d is max",b);
                }
        else
            {
                printf("\nFrom your entered value %d is max",c);
            }
        return 0;
        
    }

