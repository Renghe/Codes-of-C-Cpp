#include<iostream>
using namespace std;

int main(){
    int a,b,c,i,n;
    cout<<"Enter first 2 nos. of series";
    cin>>a>>b;
    cout<<"\n Enter max no. pf terms";
    cin>>n;
    if(n<2)
        cout<<"\n Invalid no. of terms";
    else{
        cout<<"\n\n\t"<<a<<" "<<b<<" ";
        i=2;
        while(i<n){
            c=a+b;
            cout<<c<<" ";
            a=b;
            b=c;
            i++;
        }
    }
    cout<<"\n\n";
    return 0;
}