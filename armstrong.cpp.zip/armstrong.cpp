#include <iostream>  
using namespace std;  

int main()  
{  
    int n,r,sum,i; 
    cout<<"The armstrong numbers between 1 to 1000 are::";
    for(i=1;i<=1000;i++){
        n=i;
        sum=0;
    while(n>0){    
   
    r=n%10;    
    sum=sum+(r*r*r);    
    n=n/10;}    
    
    if(sum==i)    
        cout<<i<<" ";}    

}