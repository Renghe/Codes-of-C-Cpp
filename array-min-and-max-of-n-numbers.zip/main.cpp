#include<iostream>
using namespace std;

int main(){
    int i,n,f,k;
    cout<<"enter total numbers";
    cin>>n;
    if(n<=0){
        cout<<"Invalid Number";
    }
    else{
        int a[n];
        cout<<"Enter"<<n<<"Number:\n";
        for(i=0;i<n;i++)
            cin>>a[i];
        int x=1,ch;
        while(x==1){
            cout<<"\nEnter your choice:\n\t 1.Search\n\t 2.Quit";
            cin>>ch;
            switch(ch){
                case 1:
                    cout<<"\n Enter number to be searched";
                    cin>>k;
                    f=0;
                    for(i=0;i<n;i++){
                        if(a[i]==k){
                            f=1;
                            cout<<"\n Element not found at index"<<i;
                            break;
                        }
                    }
                    if(f==0)
                        cout<<"\n Element not found in list";
                    break;
                case 2: x=0;
                    break;
            }       
        }
    }
    cout<<"\n\n\n";
    return 0;
}